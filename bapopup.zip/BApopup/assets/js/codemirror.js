jQuery(document).ready(function($) {
    if ($('#bapopup-custom-css').length) {
        wp.codeEditor.initialize($('#bapopup-custom-css'), {
            type: 'text/css',
            codemirror: {
                lineNumbers: true,
                lineWrapping: true,
                theme: 'default',
                mode: 'css'
            }
        });
    }

    if ($('#bapopup-custom-js').length) {
        wp.codeEditor.initialize($('#bapopup-custom-js'), {
            type: 'text/javascript',
            codemirror: {
                lineNumbers: true,
                lineWrapping: true,
                theme: 'default',
                mode: 'javascript'
            }
        });
    }
});