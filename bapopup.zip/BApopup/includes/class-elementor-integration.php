<?php
namespace BApopUp;

class ElementorIntegration {
    public function __construct() {
        add_action('elementor/init', [$this, 'init']);
    }

    public function init() {
        add_post_type_support('bapopup', 'elementor');
        add_action('elementor/widgets/register', [$this, 'register_widgets']);
        add_action('elementor/elements/categories_registered', [$this, 'add_widget_category']);

    }

    public function register_widgets($widgets_manager) {
        $widgets  = [
            'CloseButton',
            'AgeVerificationButton'
        ];
        foreach ($widgets as $widget) {
            $file = BAPOPUP_PATH . 'includes/widgets/' . $this->to_file_name($widget) . '.php';
            require_once($file);
            $class_name = "\\BApopUp\\Widgets\\{$widget}";
            $widgets_manager->register(new $class_name());

        }

    }
    public function add_widget_category($elements_manager){
        $elements_manager->add_category(
                'bapopup', 
                [
                    'title' => __('BA Popup', 'bapopup'),
                    'icon' => 'fa fa-plug', 
                    'active' => true,
                ],
                3 
            );
    }
    private function to_file_name($class_name) {
        return strtolower(preg_replace('/(?<!^)[A-Z]/', '-$0', $class_name));
    }


    
}