<?php
/**
 * Plugin Name: BApopup
 * Description: A powerful and flexible WordPress popup plugin that helps you create engaging popups with ease. Features include:
 * Elementor integration, customizable display rules, multiple trigger options (immediate, delay, scroll, exit-intent), 
 * smart cookie handling, and responsive design. Perfect for announcements, newsletters, promotions and more.
 * Requires PHP: 7.4
 * Version: 1.0.0
 * Text Domain: bapopup
 * Author: Abdelaziz Achatbi 
 */

 /**
 * Features:
 * - Seamless Elementor Integration
 * - Multiple Trigger Options
 * - Advanced Display Rules
 * - Smart Cookie Management
 * - Responsive Design
 * - Performance Optimized
 * - Developer Friendly
 * 
 * Need support? 
 * - Documentation: https://abdelaziz.achatbi.github.io/bapopup
 */

 if (!defined('ABSPATH')) exit;

 define('BAPOPUP_VERSION', '1.0.0');
 define('BAPOPUP_FILE', __FILE__);
 define('BAPOPUP_PATH', plugin_dir_path(__FILE__));
 define('BAPOPUP_URL', plugin_dir_url(__FILE__));
 
 require_once BAPOPUP_PATH . 'includes/class-bapopup.php';
 require_once BAPOPUP_PATH . 'includes/class-post-type.php';
 require_once BAPOPUP_PATH . 'includes/class-settings.php';
 require_once BAPOPUP_PATH . 'includes/class-elementor-integration.php';
 require_once BAPOPUP_PATH . 'includes/class-deactivate.php';

 function init_bapopup() {
    $bapopup = new BApopUp\BApopUp();
    $bapopup->init_plugin();
    
    if (is_admin()) {
        BApopUp\Deactivate::init();
    }
}
add_action('plugins_loaded', 'init_bapopup');

add_action('wp_ajax_bapopup_deactivate', function() {
    check_ajax_referer('bapopup_deactivate', 'nonce');
    
    $type = $_POST['type'] ?? 'keep';

    if($type === 'complete'){
        BApopUp\Deactivate::force_cleanup();
    }    
    deactivate_plugins(plugin_basename(__FILE__));
    wp_die();
});

register_activation_hook(__FILE__, ['BApopUp\\BApopUp', 'activate']);


add_action('elementor/init', function() {
    add_post_type_support('bapopup', 'elementor');
    
    if (class_exists('\ElementorPro\Modules\ThemeBuilder\Documents\Single')) {
        \Elementor\Plugin::$instance->documents->register_document_type(
            'bapopup',
            \ElementorPro\Modules\ThemeBuilder\Documents\Single::get_class_full_name()
        );
    }
});