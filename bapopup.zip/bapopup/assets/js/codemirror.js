jQuery(document).ready(function($) {
    // Initialize CSS editor
    if ($('#bapopup-custom-css').length) {
        wp.codeEditor.initialize($('#bapopup-custom-css'), {
            type: 'text/css',
            codemirror: {
                lineNumbers: true,
                lineWrapping: true,
                theme: 'default',
                mode: 'css'
            }
        });
    }

    // Initialize JS editor
    if ($('#bapopup-custom-js').length) {
        wp.codeEditor.initialize($('#bapopup-custom-js'), {
            type: 'text/javascript',
            codemirror: {
                lineNumbers: true,
                lineWrapping: true,
                theme: 'default',
                mode: 'javascript'
            }
        });
    }
});