jQuery(document).ready(function($) {
    function setCookie(name, value, days) {
        let expires = "";
        if (days > 0) {
            const date = new Date();
            date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
            expires = "; expires=" + date.toUTCString();
        }
        document.cookie = name + "=" + value + expires + "; path=/";
    }

    function getCookie(name) {
        const nameEQ = name + "=";
        const ca = document.cookie.split(';');
        for(let i = 0; i < ca.length; i++) {
            let c = ca[i];
            while (c.charAt(0) == ' ') c = c.substring(1, c.length);
            if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length, c.length);
        }
        return null;
    }

    function deleteCookie(name) {
        document.cookie = name + '=; Path=/; Expires=Thu, 01 Jan 1970 00:00:01 GMT;';
    }

    function showPopup(popupId) {
        const $trigger = $('.bapopup-trigger[data-popup-id="' + popupId + '"]');
        const cookieDuration = parseInt($trigger.data('cookie-duration'));
        const cookieName = 'bapopup_' + popupId;
        

        if (cookieDuration > 0 && getCookie(cookieName)) {
            return;
        }

        const content = $trigger.find('.bapopup-content').html();
        const $overlay = $('<div class="bapopup-overlay"></div>');
        const $container = $('<div class="bapopup-container"></div>');
        const $close = $('<span class="bapopup-close">&times;</span>');

        $container.append(content);
        $container.append($close);
        $overlay.append($container);
        $('body').append($overlay);
        
        $overlay.fadeIn(300);

        if (cookieDuration > 0) {
            setCookie(cookieName, '1', cookieDuration);
        }

        $overlay.on('click', function(e) {
            if ($(e.target).is($overlay) || $(e.target).is($close)) {
                $overlay.fadeOut(300, function() {
                    $(this).remove();
                });
            }
        });

        $(document).on('keydown.bapopup', function(e) {
            if (e.keyCode === 27) { 
                $overlay.fadeOut(300, function() {
                    $(this).remove();
                });
                $(document).off('keydown.bapopup');
            }
        });



        document.dispatchEvent(new CustomEvent('bapopup:shown', {
            detail: { popupId: popupId }
        }));
    
        // Close handlers
        $overlay.on('click', function(e) {
            if ($(e.target).is($overlay) || $(e.target).is($close)) {
                BApopUp.hide();
                // Trigger hidden event
                document.dispatchEvent(new CustomEvent('bapopup:hidden', {
                    detail: { popupId: popupId }
                }));
            }
        });
    }

    function initializePopups() {
        $('.bapopup-trigger').each(function() {
            const $trigger = $(this);
            const popupId = $trigger.data('popup-id');
            const triggerType = $trigger.data('trigger-type');
            const delay = parseInt($trigger.data('delay')) || 0;

           
            switch (triggerType) {
                case 'immediate':
                    showPopup(popupId);
                    break;

                case 'delay':
                    setTimeout(function() {
                        showPopup(popupId);
                    }, delay * 1000);
                    break;

                case 'scroll':
                let scrollTriggered = false;
                $(window).on('scroll.bapopup' + popupId, function() {
                    const scrollPercent = ($(window).scrollTop() / ($(document).height() - $(window).height())) * 100;
                    if (!scrollTriggered && scrollPercent > 20) { 
                        scrollTriggered = true;
                        showPopup(popupId);
                        $(window).off('scroll.bapopup' + popupId);
                    }
                });
                break;
                case 'exit_intent':
                    let exitHandled = false;
                    $(document).on('mouseleave.bapopup' + popupId, function(e) {
                        if (!exitHandled && e.clientY < 0) {
                            exitHandled = true;
                            showPopup(popupId);
                            $(document).off('mouseleave.bapopup' + popupId);
                        }
                    });
                    break;
            }
        });
    }

    function checkAllCookies() {
        const cookies = document.cookie.split(';');
        cookies.forEach(cookie => {
            const parts = cookie.split('=');
        });
       
    }

    function clearAllPopupCookies() {
        const cookies = document.cookie.split(';');
        cookies.forEach(cookie => {
            const name = cookie.split('=')[0].trim();
            if (name.startsWith('bapopup_')) {
                deleteCookie(name);
            }
        });
    }

    checkAllCookies();  
    initializePopups(); 

    window.BApopUp = {
        show: function(popupId) {
            const $trigger = $(`.bapopup-trigger[data-popup-id="${popupId}"]`);
            if ($trigger.length) {
                showPopup(popupId);
            }
        },
    
        hide: function() {
            $('.bapopup-overlay').fadeOut(300, function() {
                $(this).remove();
            });
        },
    
        clearCookies: function() {
            const cookies = document.cookie.split(';');
            cookies.forEach(cookie => {
                const name = cookie.split('=')[0].trim();
                if (name.startsWith('bapopup_')) {
                    document.cookie = name + '=; Path=/; Expires=Thu, 01 Jan 1970 00:00:01 GMT;';
                }
            });
        },
    
        on: function(event, callback) {
            document.addEventListener('bapopup:' + event, callback);
        }
    };
});