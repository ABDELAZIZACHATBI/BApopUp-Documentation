<?php
namespace BApopUp;

class Deactivate {
    public static function init() {
        if (!is_admin()) return;
        
        add_filter('plugin_action_links_' . plugin_basename(BAPOPUP_FILE), [self::class, 'add_deactivate_link']);
        add_action('admin_footer', [self::class, 'add_deactivate_popup']);
    }

    public static function add_deactivate_link($links) {
        if (isset($links['deactivate'])) {
            $links['deactivate'] = str_replace(
                '<a', 
                '<a class="bapopup-deactivate-link"',
                $links['deactivate']
            );
        }
        return $links;
    }

    public static function add_deactivate_popup() {
        global $pagenow;
        if ($pagenow !== 'plugins.php') return;
        
        ?>
        <div id="bapopup-deactivate-modal" style="display: none;">
            <div class="bapopup-modal-content">
                <h3><?php _e('Deactivate BApopup', 'bapopup'); ?></h3>
                <p><?php _e('Would you like to remove all data when deactivating ?', 'bapopup'); ?></p>
                
                <div class="uninstall-options">
                    <label>
                        <input type="radio" name="bapopup_uninstall_type" value="complete" checked>
                        <?php _e('Yes, remove all data', 'bapopup'); ?>
                    </label>
                    <label>
                        <input type="radio" name="bapopup_uninstall_type" value="keep">
                        <?php _e('No, keep the data', 'bapopup'); ?>
                    </label>
                </div>

                <div class="button-group">
                    <button class="button-primary" id="bapopup-deactivate-submit">
                        <?php _e('Deactivate', 'bapopup'); ?>
                    </button>
                    <button class="button-secondary" id="bapopup-deactivate-cancel">
                        <?php _e('Cancel', 'bapopup'); ?>
                    </button>
                </div>
            </div>
        </div>

        <style>
            #bapopup-deactivate-modal {
                position: fixed;
                z-index: 99999;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: rgba(0,0,0,0.5);
                display: flex;
                align-items: center;
                justify-content: center;
            }
            .bapopup-modal-content {
                background: #fff;
                padding: 20px;
                border-radius: 5px;
                max-width: 400px;
                width: 100%;
            }
           .bapopup-modal-content .uninstall-options {
                display: flex;
                flex-direction: column;
                gap: 10px;
            }
            .bapopup-modal-content .button-group {
                text-align: right;
                margin-top: 20px;
                display: flex;
                gap: 15px;
            }

            button#bapopup-deactivate-submit {
                background: #000;
                border-color: #000;
                color:#ffffff;
            }

            .bapopup-modal-content .button-group button {
                border-color: #000;
                color:#000 ;
            }
            
            input[type=radio]:checked::before {
                background-color: #000;
            
            }

            .bapopup-modal-content .button-group button:hover {
                border-color: #000!important;
                color:#ffffff!important;
                background: #a09d9d !important;
            }
        </style>

        <script>
        jQuery(document).ready(function($) {
            $('.bapopup-deactivate-link').on('click', function(e) {
                e.preventDefault();
                $('#bapopup-deactivate-modal').show();
            });

            $('#bapopup-deactivate-cancel').on('click', function() {
                $('#bapopup-deactivate-modal').hide();
            });

            $('#bapopup-deactivate-submit').on('click', function() {
                var type = $('input[name="bapopup_uninstall_type"]:checked').val();
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'bapopup_deactivate',
                        type: type,
                        nonce: '<?php echo wp_create_nonce('bapopup_deactivate'); ?>'
                    },
                    success: function() {
                        window.location.reload();
                    }
                });
            });
        });
        </script>
        <?php
    }

    public static function force_cleanup() {
        global $wpdb;
    
        $popups = get_posts([
            'post_type' => 'bapopup',
            'numberposts' => -1,
            'post_status' => 'any',
            'fields' => 'ids'
        ]);
    
        if (!empty($popups)) {
            foreach ($popups as $popup_id) {
                wp_delete_post($popup_id, true);
            }
        }
    
        $wpdb->query("
            DELETE FROM {$wpdb->postmeta} 
            WHERE meta_key LIKE '_bapopup%'
        ");
    
        $wpdb->query("
            DELETE FROM {$wpdb->options} 
            WHERE option_name LIKE 'bapopup%'
        ");
    
        wp_cache_flush();
    
        $wpdb->query("
            DELETE FROM {$wpdb->options} 
            WHERE option_name LIKE '_transient_bapopup%'
        ");
        $wpdb->query("
            DELETE FROM {$wpdb->options} 
            WHERE option_name LIKE '_transient_timeout_bapopup%'
        ");
    }
}