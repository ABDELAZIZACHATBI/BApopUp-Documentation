<?php
namespace BApopUp;

class ElementorIntegration {
    public function __construct() {
        add_action('elementor/init', [$this, 'init']);
    }

    public function init() {
        add_post_type_support('bapopup', 'elementor');
        
        add_action('elementor/documents/register', [$this, 'register_document_type']);
    }

    public function register_document_type() {
        if (class_exists('ElementorPro\Modules\ThemeBuilder\Documents\Single')) {
            \Elementor\Plugin::$instance->documents->register_document_type(
                'bapopup',
                \ElementorPro\Modules\ThemeBuilder\Documents\Single::get_class_full_name()
            );
        }
    }

    public function register_elementor_locations($elementor_theme_manager) {
        $elementor_theme_manager->register_location(
            'popup',
            [
                'label' => __('Popup', 'bapopup'),
                'multiple' => true,
                'edit_in_content' => true,
            ]
        );
    }
}