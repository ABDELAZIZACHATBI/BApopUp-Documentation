<?php
namespace BApopUp;

class PostType {
    public function __construct() {
        add_action('init', [$this, 'register_popup_post_type']);
        add_action('add_meta_boxes', [$this, 'add_popup_meta_boxes']);
        add_action('save_post', [$this, 'save_popup_meta']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_admin_scripts']);
       

        add_filter('manage_bapopup_posts_columns', [$this, 'add_status_columns']);
        add_action('manage_bapopup_posts_custom_column', [$this, 'custom_status_content'], 10, 2);
        add_filter('manage_edit-bapopup_sortable_columns', [$this, 'sortable_columns']);
        
        add_action('wp_ajax_toggle_popup_status', [$this, 'ajax_toggle_status']);

    }
    public function enqueue_admin_scripts($hook) {
        global $post;
        
        if ($hook == 'post-new.php' || $hook == 'post.php') {
            if ('bapopup' === $post->post_type) {
                wp_enqueue_style('bapopup-admin', BAPOPUP_URL . 'assets/css/admin.css', [], BAPOPUP_VERSION);
                wp_enqueue_script('bapopup-admin', BAPOPUP_URL . 'assets/js/admin.js', ['jquery'], BAPOPUP_VERSION, true);
            }
        }
    
        if ($hook === 'edit.php' && isset($_GET['post_type']) && $_GET['post_type'] === 'bapopup') {
            wp_enqueue_style('bapopup-admin', BAPOPUP_URL . 'assets/css/admin.css', [], BAPOPUP_VERSION);
            wp_enqueue_script('bapopup-admin', BAPOPUP_URL . 'assets/js/admin.js', ['jquery'], BAPOPUP_VERSION, true);
            wp_localize_script('bapopup-admin', 'bapopupVars', [
                'nonce' => wp_create_nonce('bapopup_nonce')
            ]);
        }
    }
    public function register_popup_post_type() {
        register_post_type('bapopup', [
            'labels' => [
                'name' => __('Popups', 'bapopup'),
                'singular_name' => __('Popup', 'bapopup'),
                'add_new' => __('Add New', 'bapopup'),
                'add_new_item' => __('Add New Popup', 'bapopup'),
                'edit_item' => __('Edit Popup', 'bapopup'),
            ],
            'public' => true,
            'supports' => [
                'title',
                'editor',
                'elementor',  
            ],
            'menu_icon' => 'dashicons-welcome-view-site',
            'show_in_menu' => false,
            'show_in_rest' => true,
            'publicly_queryable' => true,  
            'hierarchical' => false,
            'show_ui' => true,
            'show_in_nav_menus' => false,
            'exclude_from_search' => true,
            'has_archive' => false,
            'rewrite' => false,
            'elementor_edit_mode' => true,
            'elementor_library' => true
        ]);
    }

    public function add_popup_meta_boxes() {
        add_meta_box(
            'bapopup_settings',
            __('Popup Settings', 'bapopup'),
            [$this, 'render_popup_settings'],
            'bapopup'
        );

        add_meta_box(
            'bapopup_display_location',
            __('Display Location', 'bapopup'),
            [$this, 'render_display_location'],
            'bapopup'
        );
    }

    public function render_popup_settings($post) {
        wp_nonce_field('bapopup_settings', 'bapopup_nonce');
        
        $settings = get_post_meta($post->ID, '_bapopup_settings', true) ?: [];
        $start_date = isset($settings['start_date']) ? $settings['start_date'] : '';
        $end_date = isset($settings['end_date']) ? $settings['end_date'] : '';
        $trigger_type = isset($settings['trigger_type']) ? $settings['trigger_type'] : 'immediate';
        $delay = isset($settings['delay']) ? $settings['delay'] : 0;
        $enabled = isset($settings['enabled']) ? $settings['enabled'] : true;
        $cookie_duration = isset($settings['cookie_duration']) ? $settings['cookie_duration'] : 0;
        $always_show = isset($settings['always_show']) ? $settings['always_show'] : false;
        ?>
        <div class="bapopup-settings-container">
            <div class="bapopup-field-group">
                <label class="bapopup-switch">
                    <input type="checkbox" name="bapopup_enabled" <?php checked($enabled); ?>>
                    <span class="bapopup-slider round"></span>
                </label>
                <span class="bapopup-label"><?php _e('Enable Popup', 'bapopup'); ?></span>
            </div>
    
            <div class="bapopup-field-group">
                <label class="bapopup-checkbox-label">
                    <input type="checkbox" 
                           name="bapopup_always_show" 
                           id="bapopup-always-show"
                           <?php checked($always_show); ?>>
                    <span class="bapopup-label"><?php _e('Always show popup (ignore date range)', 'bapopup'); ?></span>
                </label>
            </div>
    
            <div class="bapopup-field-group date-settings" style="<?php echo $always_show ? 'display:none;' : ''; ?>">
                <h4><?php _e('Display Duration', 'bapopup'); ?></h4>
                <div class="bapopup-date-group">
                    <div class="bapopup-date-field">
                        <label><?php _e('Start Date', 'bapopup'); ?></label>
                        <input type="date" 
                               class="bapopup-date-input" 
                               name="bapopup_start_date" 
                               value="<?php echo esc_attr($start_date); ?>"
                               <?php echo $always_show ? 'disabled' : ''; ?>>
                    </div>
                    <div class="bapopup-date-field">
                        <label><?php _e('End Date', 'bapopup'); ?></label>
                        <input type="date" 
                               class="bapopup-date-input" 
                               name="bapopup_end_date" 
                               value="<?php echo esc_attr($end_date); ?>"
                               <?php echo $always_show ? 'disabled' : ''; ?>>
                    </div>
                </div>
            </div>
    
            <div class="bapopup-field-group">
                <h4><?php _e('Cookie Settings', 'bapopup'); ?></h4>
                
                <label class="bapopup-checkbox-label">
                    <input type="checkbox" 
                        name="bapopup_override_cookie" 
                        id="bapopup-override-cookie"
                        value="1"
                        <?php checked(isset($settings['override_cookie']) && $settings['override_cookie']); ?>>
                    <span class="bapopup-label"><?php _e('Override global cookie settings', 'bapopup'); ?></span>
                </label>

                <div id="individual-cookie-settings" style="<?php echo (isset($settings['override_cookie']) && $settings['override_cookie']) ? 'display:block;' : 'display:none;'; ?> margin-top: 10px;">
                    <select name="bapopup_cookie_duration" class="bapopup-select">
                        <option value="0" <?php selected($settings['cookie_duration'] ?? 0, 0); ?>><?php _e('Every time', 'bapopup'); ?></option>
                        <option value="1" <?php selected($settings['cookie_duration'] ?? 0, 1); ?>><?php _e('1 day', 'bapopup'); ?></option>
                        <option value="7" <?php selected($settings['cookie_duration'] ?? 0, 7); ?>><?php _e('1 week', 'bapopup'); ?></option>
                        <option value="30" <?php selected($settings['cookie_duration'] ?? 0, 30); ?>><?php _e('1 month', 'bapopup'); ?></option>
                        <option value="365" <?php selected($settings['cookie_duration'] ?? 0, 365); ?>><?php _e('1 year', 'bapopup'); ?></option>
                    </select>
                </div>
            </div>
    
            <div class="bapopup-field-group">
                <h4><?php _e('Trigger Settings', 'bapopup'); ?></h4>
                <div class="bapopup-trigger-field">
                    <label><?php _e('Trigger Type', 'bapopup'); ?></label>
                    <select name="bapopup_trigger_type" class="bapopup-select">
                        <option value="immediate" <?php selected($trigger_type, 'immediate'); ?>><?php _e('Immediate', 'bapopup'); ?></option>
                        <option value="delay" <?php selected($trigger_type, 'delay'); ?>><?php _e('Time Delay', 'bapopup'); ?></option>
                        <option value="scroll" <?php selected($trigger_type, 'scroll'); ?>><?php _e('On Scroll', 'bapopup'); ?></option>
                        <option value="exit_intent" <?php selected($trigger_type, 'exit_intent'); ?>><?php _e('Exit Intent', 'bapopup'); ?></option>
                    </select>
                    <p class="description"><?php _e('Choose when to show the popup', 'bapopup'); ?></p>
                </div>
                
                <div class="bapopup-delay-field" style="<?php echo $trigger_type === 'delay' ? 'display:block;' : 'display:none;'; ?>">
                    <label><?php _e('Delay (seconds)', 'bapopup'); ?></label>
                    <input type="number" 
                           class="bapopup-number-input" 
                           name="bapopup_delay" 
                           value="<?php echo esc_attr($delay); ?>" 
                           min="0">
                </div>
            </div>
        </div>
       
        <?php
    }
    
    public function render_display_location($post) {
        $settings = get_post_meta($post->ID, '_bapopup_display', true) ?: [];
        $selected_locations = isset($settings['locations']) ? $settings['locations'] : [];
        ?>
        <div class="bapopup-settings-container">
            <div class="bapopup-field-group">
                <h4><?php _e('Display Location', 'bapopup'); ?></h4>
                
                <div class="bapopup-checkbox-group">
                    <label class="bapopup-checkbox-label">
                        <input type="checkbox" class="bapopup-checkbox" name="bapopup_locations[]" value="everywhere" 
                               <?php checked(in_array('everywhere', $selected_locations)); ?>>
                        <span class="bapopup-checkbox-text"><?php _e('All Pages', 'bapopup'); ?></span>
                    </label>
                </div>
    
                <div class="bapopup-checkbox-group" id="specific-locations" 
                     style="<?php echo in_array('everywhere', $selected_locations) ? 'display:none;' : ''; ?>">
                    <label class="bapopup-checkbox-label">
                        <input type="checkbox" class="bapopup-checkbox" name="bapopup_locations[]" value="home"
                               <?php checked(in_array('home', $selected_locations)); ?>>
                        <span class="bapopup-checkbox-text"><?php _e('Homepage', 'bapopup'); ?></span>
                    </label>
    
                    <label class="bapopup-checkbox-label">
                        <input type="checkbox" class="bapopup-checkbox" name="bapopup_locations[]" value="posts"
                               <?php checked(in_array('posts', $selected_locations)); ?>>
                        <span class="bapopup-checkbox-text"><?php _e('All Posts', 'bapopup'); ?></span>
                    </label>
    
                    <label class="bapopup-checkbox-label">
                        <input type="checkbox" class="bapopup-checkbox" name="bapopup_locations[]" value="pages"
                               <?php checked(in_array('pages', $selected_locations)); ?>>
                        <span class="bapopup-checkbox-text"><?php _e('All Pages', 'bapopup'); ?></span>
                    </label>
    
                    <div class="bapopup-pages-selector">
                        <h4><?php _e('Select Specific Pages', 'bapopup'); ?></h4>
                        <div class="bapopup-pages-list">
                            <?php
                            $pages = get_pages();
                            foreach ($pages as $page) {
                                $page_id = 'page_' . $page->ID;
                                ?>
                                <label class="bapopup-checkbox-label">
                                    <input type="checkbox" class="bapopup-checkbox" name="bapopup_specific_pages[]"
                                           value="<?php echo $page->ID; ?>"
                                           <?php checked(in_array($page_id, $selected_locations)); ?>>
                                    <span class="bapopup-checkbox-text"><?php echo $page->post_title; ?></span>
                                </label>
                                <?php
                            }
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }

    public function save_popup_meta($post_id) {
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
        if (!isset($_POST['bapopup_nonce']) || !wp_verify_nonce($_POST['bapopup_nonce'], 'bapopup_settings')) return;
        if (!current_user_can('edit_post', $post_id)) return;

        $settings = [
            'enabled' => isset($_POST['bapopup_enabled']),
            'always_show' => isset($_POST['bapopup_always_show']),
            'override_cookie' => isset($_POST['bapopup_override_cookie']),
            'cookie_duration' => isset($_POST['bapopup_override_cookie']) ? intval($_POST['bapopup_cookie_duration']) : null,
            'start_date' => sanitize_text_field($_POST['bapopup_start_date'] ?? ''),
            'end_date' => sanitize_text_field($_POST['bapopup_end_date'] ?? ''),
            'trigger_type' => sanitize_text_field($_POST['bapopup_trigger_type'] ?? 'immediate'),
            'delay' => intval($_POST['bapopup_delay'] ?? 0)
        ];
        ?>     
        <script>
            document.cookie.split(";").forEach(function(c) { 
            document.cookie = c.replace(/^ +/, "").replace(/=.*/, "=;expires=Thu, 01 Jan 1970 00:00:00 UTC;path=/"); 
            });
        </script>
        <?php
        update_post_meta($post_id, '_bapopup_settings', $settings);

        

        $locations = [];
        
        if (isset($_POST['bapopup_locations'])) {
            $locations = array_map('sanitize_text_field', $_POST['bapopup_locations']);
        }
        
        if (isset($_POST['bapopup_specific_pages'])) {
            foreach ($_POST['bapopup_specific_pages'] as $page_id) {
                $locations[] = 'page_' . intval($page_id);
            }
        }
        
        update_post_meta($post_id, '_bapopup_display', ['locations' => $locations]);


    }

    public function should_display_popup($popup_id) {
    $display = get_post_meta($popup_id, '_bapopup_display', true);
    $locations = isset($display['locations']) ? $display['locations'] : [];

    $conditions = apply_filters('bapopup_display_conditions', [
        'locations' => $locations,
        'popup_id' => $popup_id
    ], $popup_id);
    
    if (empty($locations)) {
        return false;
    }

    $settings = get_post_meta($popup_id, '_bapopup_settings', true);
    if (!isset($settings['enabled']) || !$settings['enabled']) {
        return false;
    }

    if (isset($settings['always_show']) && $settings['always_show']) {
        return true;
    }

    $start_date = !empty($settings['start_date']) ? strtotime($settings['start_date']) : false;
    $end_date = !empty($settings['end_date']) ? strtotime($settings['end_date']) : false;
    
    $current_time = current_time('timestamp');

    if ($start_date && $current_time < $start_date) {
        return false;
    }
    
    if ($end_date && $current_time > strtotime('+1 day', $end_date)) {
        return false;
    }

    if (in_array('everywhere', $locations)) {
        return true;
    }
    
    if (is_front_page() && in_array('home', $locations)) {
        return true;
    }
    
    if (is_single() && in_array('posts', $locations)) {
        return true;
    }
    
    if (is_page() && in_array('pages', $locations)) {
        return true;
    }
    
    if (is_page()) {
        $page_id = get_the_ID();
        if (in_array('page_' . $page_id, $locations)) {
            return true;
        }
    }
    
    return false;
    }

    public function add_status_columns($columns) {
        $new_columns = array();
        
        foreach($columns as $key => $value) {
            if ($key === 'title') {
                $new_columns[$key] = $value;
                $new_columns['enabled'] = __('Enabled', 'bapopup');
            } else {
                $new_columns[$key] = $value;
            }
        }
        
        return $new_columns;
    }
    
    public function custom_status_content($column, $post_id) {
        if ($column === 'enabled') {
            $settings = get_post_meta($post_id, '_bapopup_settings', true) ?: array();
            $enabled = isset($settings['enabled']) ? $settings['enabled'] : true;
            
            echo '<div class="bapopup-toggle-wrapper">';
            echo '<label class="bapopup-switch">';
            echo '<input type="checkbox" 
                         class="bapopup-status-toggle" 
                         data-post-id="' . esc_attr($post_id) . '" 
                         ' . checked($enabled, true, false) . '>';
            echo '<span class="bapopup-slider round"></span>';
            echo '</label>';
            echo '</div>';
        }
    }
    
    public function sortable_columns($columns) {
        $columns['enabled'] = 'enabled';
        return $columns;
    }
    
    public function ajax_toggle_status() {
        check_ajax_referer('bapopup_nonce', 'nonce');
        
        $post_id = intval($_POST['post_id']);
        if (!current_user_can('edit_post', $post_id)) {
            wp_send_json_error();
            return;
        }
        
        $settings = get_post_meta($post_id, '_bapopup_settings', true) ?: array();
        $settings['enabled'] = !isset($settings['enabled']) || !$settings['enabled'];
        
        update_post_meta($post_id, '_bapopup_settings', $settings);
        wp_send_json_success(['enabled' => $settings['enabled']]);
    }

  
}