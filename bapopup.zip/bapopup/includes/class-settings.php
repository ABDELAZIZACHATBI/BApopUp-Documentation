<?php
namespace BApopUp;

class Settings {
    public function __construct() {
        add_action('admin_init', [$this, 'register_settings']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_codemirror']);

    }


    public function enqueue_codemirror($hook) {
        if ($hook !== 'bapopup_page_bapopup-settings') return;
    
        wp_enqueue_code_editor(['type' => 'text/css']);
        wp_enqueue_code_editor(['type' => 'text/javascript']);
        
        wp_enqueue_script(
            'bapopup-codemirror',
            BAPOPUP_URL . 'assets/js/codemirror.js',
            ['jquery', 'code-editor'],
            BAPOPUP_VERSION,
            true
        );
    }
    public function register_settings() {
        
        register_setting('bapopup_options', 'bapopup_settings', [
            'sanitize_callback' => function($input) {
                ?>
                <script>
                jQuery(document).ready(function($) {
                    const cookies = document.cookie.split(';');
            
                    cookies.forEach(cookie => {
                        const cookieName = cookie.split('=')[0].trim();
                        if (cookieName.startsWith('bapopup_')) {
                            document.cookie = cookieName + '=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;';
                        }
                    });
                });
                </script>
                <?php
                return $input;
            }
        ]);

        register_setting('bapopup_options', 'bapopup_custom_css');
        register_setting('bapopup_options', 'bapopup_custom_js');
    
        add_settings_section(
            'bapopup_general',
            __('General Settings', 'bapopup'),
            [$this, 'render_general_section'],
            'bapopup-settings'
        );

        add_settings_field(
            'cookie_duration',
            __('Cookie Duration :', 'bapopup'),
            [$this, 'render_cookie_duration'],
            'bapopup-settings',
            'bapopup_general'
        );

        add_settings_section(
            'bapopup_custom_code',
            __('Custom Code', 'bapopup'),
            [$this, 'render_custom_code_section'],
            'bapopup-settings'
        );
        add_settings_field(
            'custom_css',
            __('Custom CSS', 'bapopup'),
            [$this, 'render_custom_css'],
            'bapopup-settings',
            'bapopup_custom_code'
        );
    
        add_settings_field(
            'custom_js',
            __('Custom JavaScript', 'bapopup'),
            [$this, 'render_custom_js'],
            'bapopup-settings',
            'bapopup_custom_code'
        );
    }
    public function render_custom_css() {
        $custom_css = get_option('bapopup_custom_css', '');
        ?>
        <div class="bapopup-code-editor">
            <textarea id="bapopup-custom-css" 
                      name="bapopup_custom_css" 
                      class="widefat" 
                      rows="10"><?php echo esc_textarea($custom_css); ?></textarea>
            <p class="description">
                <?php _e('Add custom CSS to style your popups. This CSS will be loaded on all pages where popups are active.', 'bapopup'); ?>
            </p>
        </div>
        <?php
    }
    
    public function render_custom_js() {
        $custom_js = get_option('bapopup_custom_js', '');
        ?>
        <div class="bapopup-code-editor">
            <textarea id="bapopup-custom-js" 
                      name="bapopup_custom_js" 
                      class="widefat" 
                      rows="10"><?php echo esc_textarea($custom_js); ?></textarea>
            <p class="description">
                <?php _e('Add custom JavaScript code. This code will be loaded on all pages where popups are active.', 'bapopup'); ?>
            </p>
        </div>
        <?php
    }
    public function render_custom_code_section() {
        echo '<p>' . __('Add custom CSS and JavaScript code for your popups.', 'bapopup') . '</p>';
    }

    public function render_general_section() {
        echo '<p>' . __('Configure general settings for your popups.', 'bapopup') . '</p>';
    }

    public function render_cookie_duration() {
        $options = get_option('bapopup_settings', ['cookie_duration' => 0]);
        $duration = isset($options['cookie_duration']) ? $options['cookie_duration'] : 0;
        ?>
        <select name="bapopup_settings[cookie_duration]">
            <option value="0" <?php selected($duration, 0); ?>><?php _e('Every time', 'bapopup'); ?></option>
            <option value="1" <?php selected($duration, 1); ?>><?php _e('1 day', 'bapopup'); ?></option>
            <option value="7" <?php selected($duration, 7); ?>><?php _e('1 week', 'bapopup'); ?></option>
            <option value="30" <?php selected($duration, 30); ?>><?php _e('1 month', 'bapopup'); ?></option>
            <option value="365" <?php selected($duration, 365); ?>><?php _e('1 year', 'bapopup'); ?></option>
        </select>
        <p class="description">
            <?php _e('Choose how long before the popup shows again to the same visitor.', 'bapopup'); ?>
        </p>
        <?php
    }



}   