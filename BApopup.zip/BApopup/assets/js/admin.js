jQuery(document).ready(function($) {
    $('input[value="everywhere"]').on('change', function() {
        if($(this).is(':checked')) {
            $('#specific-locations').slideUp();
        } else {
            $('#specific-locations').slideDown();
        }
    });

    $('select[name="bapopup_trigger_type"]').on('change', function() {
        if($(this).val() === 'delay') {
            $('.bapopup-delay-field').slideDown();
        } else {
            $('.bapopup-delay-field').slideUp();
        }
    });


    $('#bapopup-always-show').on('change', function() {
        if ($(this).is(':checked')) {
            $('.date-settings').slideUp();
            $('.bapopup-date-input').prop('disabled', true);
        } else {
            $('.date-settings').slideDown();
            $('.bapopup-date-input').prop('disabled', false);
        }
    });

    $('select[name="bapopup_trigger_type"]').on('change', function() {
        if ($(this).val() === 'delay') {
            $('.bapopup-delay-field').slideDown();
        } else {
            $('.bapopup-delay-field').slideUp();
        }
    });


    $('#bapopup-override-cookie').on('change', function() {
        if ($(this).is(':checked')) {
            $('#individual-cookie-settings').slideDown();
        } else {
            $('#individual-cookie-settings').slideUp();
        }
    });


    $('.bapopup-status-toggle').on('change', function() {
        const $toggle = $(this);
        const postId = $toggle.data('post-id');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'toggle_popup_status',
                post_id: postId,
                nonce: bapopupVars.nonce
            },
            success: function(response) {
                if (!response.success) {
                    $toggle.prop('checked', !$toggle.prop('checked'));
                }
            },
            error: function() {
                $toggle.prop('checked', !$toggle.prop('checked'));
                alert('Error updating status');
            }
        });
    });
    


    $('#specific-pages-input').on('keyup', function() {
        const searchText = $(this).val().toLowerCase();
        
        $('.bapopup-pages-list label').each(function() {
          const pageTitle = $(this).find('.bapopup-checkbox-text').text().toLowerCase();
          $(this).toggle(pageTitle.includes(searchText));
        });
      });

    $('#bapopup_is_age_verification').on('change', function() {
        if ($(this).is(':checked')) {
            $('.age-verification-settings').slideDown();
        } else {
            $('.age-verification-settings').slideUp();
        }
    });

    const startDateInput = $('input[name="bapopup_start_date"]');
    const endDateInput = $('input[name="bapopup_end_date"]');
    
    const calculateMinEndDate = (startDate) => {
        const minDate = new Date(startDate);
        minDate.setDate(minDate.getDate());
        return minDate.toISOString().split('T')[0];
    }
    
    startDateInput.on('change', function() {
        const startDate = new Date($(this).val());
        const formattedMinDate = calculateMinEndDate(startDate);
        
        endDateInput.attr('min', formattedMinDate);
        
        if(endDateInput.val() && new Date(endDateInput.val()) < new Date(formattedMinDate)) {
            endDateInput.val('');
        }
    });
    
    if(startDateInput.val()) {
        const formattedMinDate = calculateMinEndDate(startDateInput.val());
        endDateInput.attr('min', formattedMinDate);
    }
});


