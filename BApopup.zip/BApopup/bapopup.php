<?php
/**
 * Plugin Name: BApopup
 * Plugin URI: https://abdelazizachatbi.github.io/BApopUp-Documentation/
 * Description: A powerful WordPress popup plugin with Elementor integration that helps you create engaging popups with ease. Features include:
 * Elementor integration, customizable display rules, multiple trigger options (immediate, delay, scroll, exit-intent), 
 * smart cookie handling, age verification, and responsive design.
 * By Abdelaziz Achatbi | Documentation | Support | View details
 * Version: 1.0.0
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * Author: Abdelaziz Achatbi
 * Text Domain: bapopup
 *
 * @package BApopup
 * @author Abdelaziz Achatbi
 * @version 1.0.0
 *
 * Documentation: https://abdelazizachatbi.github.io/BApopUp-Documentation/
 */

 if (!defined('ABSPATH')) exit;

 define('BAPOPUP_VERSION', '1.0.0');
 define('BAPOPUP_FILE', __FILE__);
 define('BAPOPUP_PATH', plugin_dir_path(__FILE__));
 define('BAPOPUP_URL', plugin_dir_url(__FILE__));
 
 require_once BAPOPUP_PATH . 'includes/class-bapopup.php';
 require_once BAPOPUP_PATH . 'includes/class-post-type.php';
 require_once BAPOPUP_PATH . 'includes/class-settings.php';
 require_once BAPOPUP_PATH . 'includes/class-elementor-integration.php';
 require_once BAPOPUP_PATH . 'includes/class-deactivate.php';

 function init_bapopup() {
    $bapopup = new BApopUp\BApopUp();
    $bapopup->init_plugin();
    
    if (is_admin()) {
        BApopUp\Deactivate::init();
    }
}
add_action('plugins_loaded', 'init_bapopup');

add_action('wp_ajax_bapopup_deactivate', function() {
    check_ajax_referer('bapopup_deactivate', 'nonce');
    
    $type = $_POST['type'] ?? 'keep';

    if($type === 'complete'){
        BApopUp\Deactivate::force_cleanup();
    }    
    deactivate_plugins(plugin_basename(__FILE__));
    wp_die();
});

register_activation_hook(__FILE__, ['BApopUp\\BApopUp', 'activate']);

