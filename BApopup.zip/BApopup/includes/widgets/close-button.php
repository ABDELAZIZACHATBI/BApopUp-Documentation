<?php
namespace BApopUp\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Icons_Manager;

class CloseButton extends Widget_Base {
   public function get_name() {
       return 'bapopup_close_button';
   }

   public function get_title() {
       return __('Popup Close Button', 'bapopup');
   }

   public function get_icon() {
       return 'eicon-close';
   }

   public function get_categories() {
       return ['bapopup'];
   }

   protected function register_controls() {
       $this->start_controls_section(
           'content_section',
           [
               'label' => __('Button Content', 'bapopup'),
               'tab' => Controls_Manager::TAB_CONTENT, 
           ]
       );

       $this->add_control(
           'button_type',
           [
               'label' => __('Button Type', 'bapopup'),
               'type' => Controls_Manager::SELECT,
               'default' => 'icon',
               'options' => [
                   'icon' => __('Icon', 'bapopup'),
                   'text' => __('Text', 'bapopup'),
               ],
           ]
       );

       $this->add_control(
           'selected_icon',
           [
               'label' => __('Icon', 'bapopup'),
               'type' => Controls_Manager::ICONS,
               'default' => [
                   'value' => 'fas fa-times',
                   'library' => 'fa-solid',
               ],
               'condition' => [
                   'button_type' => 'icon',
               ],
           ]
       );

       $this->add_control(
           'button_text',
           [
               'label' => __('Button Text', 'bapopup'),
               'type' => Controls_Manager::TEXT,
               'default' => '×',
               'condition' => [
                   'button_type' => 'text',
               ],
           ]
       );

       $this->end_controls_section();

       $this->start_controls_section(
           'section_style',
           [
               'label' => __('Button Style', 'bapopup'),
               'tab' => Controls_Manager::TAB_STYLE,
           ]
       );

       $this->add_group_control(
           \Elementor\Group_Control_Typography::get_type(),
           [
               'name' => 'typography',
               'selector' => '{{WRAPPER}} .bapopup-close-btn',
           ]
       );

       $this->add_group_control(
           \Elementor\Group_Control_Text_Shadow::get_type(),
           [
               'name' => 'text_shadow',
               'selector' => '{{WRAPPER}} .bapopup-close-btn',
           ]
       );

       $this->start_controls_tabs('button_states');

       $this->start_controls_tab(
           'button_normal',
           [
               'label' => __('Normal', 'bapopup'),
           ]
       );

       $this->add_control(
           'color',
           [
               'label' => __('Color', 'bapopup'),
               'type' => Controls_Manager::COLOR,
               'selectors' => [
                   '{{WRAPPER}} .bapopup-close-btn' => 'color: {{VALUE}};',
                   '{{WRAPPER}} .bapopup-close-btn svg' => 'fill: {{VALUE}};',
               ],
           ]
       );


       $this->add_group_control(
           \Elementor\Group_Control_Background::get_type(),
           [
               'name' => 'background',
               'types' => ['classic', 'gradient'],
               'selector' => '{{WRAPPER}} .bapopup-close-btn',
               'fields_options' => [
                   'background' => [
                       'default' => 'classic',
                   ],
                   'color' => [
                       'default' => '#ffffff',
                   ],
               ],
           ]
       );

       $this->add_control(
           'border_type',
           [
               'label' => __('Border Type', 'bapopup'),
               'type' => Controls_Manager::SELECT,
               'default' => 'solid',
               'options' => [
                   'none' => __('None', 'bapopup'),
                   'solid' => __('Solid', 'bapopup'),
                   'double' => __('Double', 'bapopup'),
                   'dotted' => __('Dotted', 'bapopup'),
                   'dashed' => __('Dashed', 'bapopup'),
               ],
               'selectors' => [
                   '{{WRAPPER}} .bapopup-close-btn' => 'border-style: {{VALUE}};',
               ],
           ]
       );

       $this->add_control(
           'border_width',
           [
               'label' => __('Border Width', 'bapopup'),
               'type' => Controls_Manager::DIMENSIONS,
               'selectors' => [
                   '{{WRAPPER}} .bapopup-close-btn' => 'border-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
               ],
               'condition' => [
                   'border_type!' => 'none',
               ],
           ]
       );

       $this->add_control(
           'border_color',
           [
               'label' => __('Border Color', 'bapopup'),
               'type' => Controls_Manager::COLOR,
               'default' => '',
               'selectors' => [
                   '{{WRAPPER}} .bapopup-close-btn' => 'border-color: {{VALUE}};',
               ],
               'condition' => [
                   'border_type!' => 'none',
               ],
           ]
       );

       $this->end_controls_tab();

       $this->start_controls_tab(
           'button_hover',
           [
               'label' => __('Hover', 'bapopup'),
           ]
       );

       $this->add_control(
           'hover_color',
           [
               'label' => __('Color', 'bapopup'),
               'type' => Controls_Manager::COLOR,
               'selectors' => [
                   '{{WRAPPER}} .bapopup-close-btn:hover' => 'color: {{VALUE}};',
                   '{{WRAPPER}} .bapopup-close-btn:hover svg' => 'fill: {{VALUE}};',
               ],
           ]
       );

       $this->add_group_control(
           \Elementor\Group_Control_Background::get_type(),
           [
               'name' => 'hover_background',
               'types' => ['classic', 'gradient'],
               'selector' => '{{WRAPPER}} .bapopup-close-btn:hover',
           ]
       );

       $this->add_control(
           'hover_border_color',
           [
               'label' => __('Border Color', 'bapopup'),
               'type' => Controls_Manager::COLOR,
               'selectors' => [
                   '{{WRAPPER}} .bapopup-close-btn:hover' => 'border-color: {{VALUE}};',
               ],
               'condition' => [
                   'border_type!' => 'none',
               ],
           ]
       );

       $this->end_controls_tab();

       $this->end_controls_tabs();

       $this->add_responsive_control(
           'button_width',
           [
               'label' => __('Width', 'bapopup'),
               'type' => Controls_Manager::SLIDER,
               'size_units' => ['px', '%', 'em', 'custom'],
               'range' => [
                   'px' => [
                       'min' => 0,
                       'max' => 200,
                       'step' => 1,
                   ],
                   '%' => [
                       'min' => 0,
                       'max' => 100,
                   ],
                   'em' => [
                       'min' => 0,
                       'max' => 20,
                   ],
               ],
               'default' => [
                   'unit' => 'px',
                   'size' => 32,
               ],
               'selectors' => [
                   '{{WRAPPER}} .bapopup-close-btn' => 'width: {{SIZE}}{{UNIT}};',
               ],
               'separator' => 'before'
           ]
       );

       $this->add_responsive_control(
           'button_height',
           [
               'label' => __('Height', 'bapopup'),
               'type' => Controls_Manager::SLIDER,
               'size_units' => ['px', '%', 'em', 'custom'],
               'range' => [
                   'px' => [
                       'min' => 0,
                       'max' => 200,
                       'step' => 1,
                   ],
                   '%' => [
                       'min' => 0,
                       'max' => 100,
                   ],
                   'em' => [
                       'min' => 0,
                       'max' => 20,
                   ],
               ],
               'default' => [
                   'unit' => 'px',
                   'size' => 32,
               ],
               'selectors' => [
                   '{{WRAPPER}} .bapopup-close-btn' => 'height: {{SIZE}}{{UNIT}};',
               ]
           ]
       );

       $this->add_control(
           'border_radius',
           [
               'label' => __('Border Radius', 'bapopup'),
               'type' => Controls_Manager::DIMENSIONS,
               'size_units' => ['px', '%', 'em'],
               'default' => [
                   'top' => '50',
                   'right' => '50',
                   'bottom' => '50', 
                   'left' => '50',
                   'unit' => '%',
                   'isLinked' => true,
               ],
               'selectors' => [
                   '{{WRAPPER}} .bapopup-close-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
               ],
           ]
       );

       $this->add_responsive_control(
           'button_margin',
           [
               'label' => __('Margin', 'bapopup'),
               'type' => Controls_Manager::DIMENSIONS,
               'size_units' => ['px', '%', 'em', 'custom'],
               'selectors' => [
                   '{{WRAPPER}} .bapopup-close-btn' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
               ],
           ]
       );

       $this->add_responsive_control(
           'button_padding',
           [
               'label' => __('Padding', 'bapopup'),
               'type' => Controls_Manager::DIMENSIONS,
               'size_units' => ['px', '%', 'em', 'custom'],
               'selectors' => [
                   '{{WRAPPER}} .bapopup-close-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
               ],
           ]
       );

       $this->add_control(
           'transition_duration',
           [
               'label' => __('Transition Duration', 'bapopup'),
               'type' => Controls_Manager::SLIDER,
               'range' => [
                   'px' => [
                       'max' => 3,
                       'step' => 0.1,
                   ],
               ],
               'selectors' => [
                   '{{WRAPPER}} .bapopup-close-btn' => 'transition-duration: {{SIZE}}s',
               ],
           ]
       );

       $this->add_control(
           'hover_animation',
           [
               'label' => __('Hover Animation', 'bapopup'),
               'type' => Controls_Manager::HOVER_ANIMATION,
           ]
       );

       $this->end_controls_section();
   }

   protected function render() {
       $settings = $this->get_settings_for_display();
       ?>
       <div class="bapopup-close-btn bapopup-close close-btn elementor-animation-<?php echo esc_attr($settings['hover_animation']); ?>" role="button">
           <?php 
           switch($settings['button_type']) {
               case 'icon':
                   Icons_Manager::render_icon($settings['selected_icon'], ['aria-hidden' => 'true']);
                   break;
               case 'text':
                   echo esc_html($settings['button_text']);
                   break;
           }
           ?>
       </div>
       <style>
           .bapopup-close-btn {
               position: relative;
               top: 0px;
               right: 0px;
               display: flex;
               align-items: center;
               justify-content: center;
               cursor: pointer;
               padding: 0px;
               line-height: 1;
           }
           
           .bapopup-close-btn i, 
           .bapopup-close-btn svg {
               width: 1em;
               height: 1em;
               position: relative;
               display: block;
           }
       </style>
       <?php
   }
}