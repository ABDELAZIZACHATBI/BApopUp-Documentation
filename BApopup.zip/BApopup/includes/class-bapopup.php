<?php
namespace BApopUp;

class BApopUp {
    public function init_plugin() {
        $post_type = new PostType();
        $settings = new Settings();
        
        if (did_action('elementor/loaded')) {
            $elementor = new ElementorIntegration();
        }

        add_action('admin_menu', [$this, 'add_admin_menu']);
        add_action('admin_bar_menu', [$this, 'add_admin_bar_item'], 999);

        add_action('wp_enqueue_scripts', [$this, 'enqueue_frontend_assets']);
        add_action('wp_footer', [$this, 'maybe_display_popups']);
        add_action('wp_ajax_get_popup_content', [$this, 'get_popup_content']);
        add_action('wp_ajax_nopriv_get_popup_content', [$this, 'get_popup_content']);

        date_default_timezone_set(wp_timezone_string());

    }

    public function add_admin_menu() {
        add_menu_page(
            __('BApopUp', 'bapopup'),           
            __('BApopup', 'bapopup'),           
            'manage_options',                    
            'edit.php?post_type=bapopup',        
            null,                               
            'dashicons-welcome-view-site',     
            25                                  
        );
    
        add_submenu_page(
            'edit.php?post_type=bapopup',      
            __('All Popups', 'bapopup'),       
            __('All Popups', 'bapopup'),      
            'manage_options',                   
            'edit.php?post_type=bapopup'       
        );
    
        add_submenu_page(
            'edit.php?post_type=bapopup',      
            __('Add New Popup', 'bapopup'),    
            __('Add New', 'bapopup'),          
            'manage_options',                   
            'post-new.php?post_type=bapopup'   
        );
    
        add_submenu_page(
            'edit.php?post_type=bapopup',      
            __('BApopUp Settings', 'bapopup'), 
            __('Settings', 'bapopup'),         
            'manage_options',                  
            'bapopup-settings',                
            [$this, 'render_settings_page']    
        );

    }

    public function add_admin_bar_item($admin_bar) {
        $admin_bar->add_node([
            'id'    => 'bapopup',
            'title' => '<span class="ab-icon dashicons dashicons-welcome-view-site"></span>',
            'href'  => admin_url('edit.php?post_type=bapopup'),
        ]);
    
        $admin_bar->add_node([
            'id'     => 'bapopup-new',
            'parent' => 'bapopup',
            'title'  => __('New Popup', 'bapopup'),
            'href'   => admin_url('post-new.php?post_type=bapopup'),
        ]);
    
        $admin_bar->add_node([
            'id'     => 'bapopup-all',
            'parent' => 'bapopup',
            'title'  => __('All Popups', 'bapopup'),
            'href'   => admin_url('edit.php?post_type=bapopup'),
        ]);
    
        $admin_bar->add_node([
            'id'     => 'bapopup-settings',
            'parent' => 'bapopup',
            'title'  => __('Settings', 'bapopup'),
            'href'   => admin_url('admin.php?page=bapopup-settings'),
        ]);
    }

    public function render_settings_page() {
        ?>
       
        <div class="wrap bapopup_options">
            <h1><?php echo esc_html__('BApopUp Settings', 'bapopup'); ?></h1>
            <form method="post" action="options.php" id="bapopupSettings">
                <?php
                settings_fields('bapopup_options');
                do_settings_sections('bapopup-settings');
                submit_button();
                ?>
            </form>
            
        </div>
        <script>
        jQuery(document).ready(function($) {
            $('#bapopupSettings').on('submit', function() {
                const cookies = document.cookie.split(';');
            
                cookies.forEach(cookie => {
                    const cookieName = cookie.split('=')[0].trim();
                    if (cookieName.startsWith('bapopup_')) {
                        document.cookie = cookieName + '=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;';
                    }
                });
            });
        });
        </script>
        <?php
    }

    public static function maybe_display_popups() {
        $global_settings = get_option('bapopup_settings', ['cookie_duration' => 7]);
    
        $popups = get_posts([
            'post_type' => 'bapopup',
            'post_status' => 'publish',
            'posts_per_page' => -1
        ]);
    
        foreach ($popups as $popup) {
            $post_type = new PostType();
            if ($post_type->should_display_popup($popup->ID)) {

                do_action('bapopup_before_show', $popup->ID);

                $popup_settings = get_post_meta($popup->ID, '_bapopup_settings', true);
                
                $cookie_duration = isset($popup_settings['override_cookie']) && isset($popup_settings['cookie_duration']) 
                    ? $popup_settings['cookie_duration'] 
                    : $global_settings['cookie_duration'];
       
                $content = '';
                $ba_classes ="";
                if (class_exists('\Elementor\Plugin')) {
                    $elementor = \Elementor\Plugin::instance();
                    
                    $built_with_elementor = get_post_meta($popup->ID, '_elementor_edit_mode', true);

                    if ($built_with_elementor && $elementor->documents->get($popup->ID)) {
                        $content = $elementor->frontend->get_builder_content($popup->ID);
                    } else {
                        $content = do_shortcode(wpautop($popup->post_content));
                        $ba_classes = "ba_white";
                    }
                } else {
                    $content = do_shortcode(wpautop($popup->post_content));
                    $ba_classes = "ba_white";
                }

                $extra_attrs = '';
                if (isset($popup_settings['is_age_verification']) && $popup_settings['is_age_verification']) {
                    $extra_attrs .= ' data-age-verification="true"';
                    $extra_attrs .= ' data-min-age="' . esc_attr($popup_settings['minimum_age'] ?? 18) . '"';
                }
                ?>
                <div class="bapopup-trigger" 
                     data-popup-id="<?php echo esc_attr($popup->ID); ?>"
                     data-trigger-type="<?php echo esc_attr($popup_settings['trigger_type'] ?? 'immediate'); ?>"
                     data-delay="<?php echo esc_attr($popup_settings['delay'] ?? '0'); ?>"
                     data-cookie-duration="<?php echo esc_attr($cookie_duration); ?>"
                     data-bg-classes="<?php echo esc_attr($ba_classes); ?>"
                     <?php echo $extra_attrs; ?>>
                    <div class="bapopup-content  "style="display: none;">
                        <?php echo $content; ?>
                    </div>
                </div>
                <?php
                do_action('bapopup_after_show', $popup->ID);
            }
        }
    }

    public function enqueue_frontend_assets() {
        wp_enqueue_script('jquery');
        
        wp_enqueue_style(
            'bapopup-style',
            BAPOPUP_URL . 'assets/css/bapopup.css',
            [],
            BAPOPUP_VERSION
        );

        wp_enqueue_script(
            'bapopup-script',
            BAPOPUP_URL . 'assets/js/bapopup.js',
            ['jquery'],
            BAPOPUP_VERSION,
            true
        );

        wp_localize_script('bapopup-script', 'bapopupVars', [
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('bapopup-nonce')
        ]);

        $custom_css = get_option('bapopup_custom_css');
        if (!empty($custom_css)) {
            wp_add_inline_style('bapopup-style', $custom_css);
        }
    
        $custom_js = get_option('bapopup_custom_js');
        if (!empty($custom_js)) {
            wp_add_inline_script('bapopup-script', $custom_js);
        }
    }

    

    public static function get_popup_content() {
        check_ajax_referer('bapopup-nonce', 'nonce');
        
        $popup_id = intval($_POST['popup_id']);
        $popup = get_post($popup_id);
        
        if (!$popup || $popup->post_type !== 'bapopup') {
            wp_send_json_error(['message' => 'Invalid popup']);
            return;
        }
    
        $content = '';
        
        if (class_exists('\Elementor\Plugin')) {
            $elementor = \Elementor\Plugin::instance();
            if ($elementor->documents->get($popup_id)) {
                $content = $elementor->frontend->get_builder_content($popup_id);
            } else {
                $content = wpautop($popup->post_content);
            }
        } else {
            $content = wpautop($popup->post_content);
        }
    
        wp_send_json_success([
            'content' => $content,
            'title' => $popup->post_title
        ]);
    }

    public static function activate() {
        delete_option('bapopup_settings');
        delete_option('bapopup_uninstall_type');
        
        add_option('bapopup_settings', [
            'cookie_duration' => 0,
        ]);
    }


   
}