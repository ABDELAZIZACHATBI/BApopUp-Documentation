<?php
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

require_once dirname(__FILE__) . '/includes/class-deactivate.php';
BApopUp\Deactivate::force_cleanup();